class CreateZawodniks < ActiveRecord::Migration[5.0]
  def change
    create_table :zawodniks do |t|
      t.string :Nazwisko
      t.string :Imie
      t.integer :PESEL
      t.integer :Telefon
      t.string :Adres
      t.string :Status

      t.timestamps
    end
  end
end
