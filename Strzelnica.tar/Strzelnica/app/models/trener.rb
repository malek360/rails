class Trener < ApplicationRecord
belongs_to :Zawodnik
end
