class TrenersController < ApplicationController
  before_action :set_trener, only: [:show, :edit, :update, :destroy]

  # GET /treners
  # GET /treners.json
  def index
    @treners = Trener.all
	@trener = Trener.new
	@Zawodnik= Zawodnik.all
  end

  # GET /treners/1
  # GET /treners/1.json
  def show
  end

  # GET /treners/new
  def new
    @trener = Trener.new
  end

  # GET /treners/1/edit
  def edit
  end

  # POST /treners
  # POST /treners.json
  def create
    @trener = Trener.new(trener_params)

    respond_to do |format|
      if @trener.save
        format.html { redirect_to treners_path, notice: 'Trener został poprawnie dodany.' }
        format.json { render :show, status: :created, location: @trener }
      else
        format.html { render :new }
        format.json { render json: @trener.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /treners/1
  # PATCH/PUT /treners/1.json
  def update
    respond_to do |format|
      if @trener.update(trener_params)
        format.html { redirect_to @trener, notice: 'Dane trenera zostały zaktualizowane.' }
        format.json { render :show, status: :ok, location: @trener }
      else
        format.html { render :edit }
        format.json { render json: @trener.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /treners/1
  # DELETE /treners/1.json
  def destroy
    @trener.destroy
    respond_to do |format|
      format.html { redirect_to treners_url, notice: 'Trener został usunięty.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_trener
      @trener = Trener.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def trener_params
      params.require(:trener).permit(:Imie, :Nazwisko,:Zawodnik_id)
    end
end
