class ZawodniksController < ApplicationController
  before_action :set_zawodnik, only: [:show, :edit, :update, :destroy]

  # GET /zawodniks
  # GET /zawodniks.json
  def index
    @zawodniks = Zawodnik.all
    @zawodnik = Zawodnik.new

  end

  # GET /zawodniks/1
  # GET /zawodniks/1.json
  def show
  end

  # GET /zawodniks/new
  def new
    @zawodnik = Zawodnik.new
  end

  # GET /zawodniks/1/edit
  def edit
  end

  # POST /zawodniks
  # POST /zawodniks.json
  def create
    @zawodnik = Zawodnik.new(zawodnik_params)

    respond_to do |format|
      if @zawodnik.save
        format.html { redirect_to zawodniks_path, notice: 'Zawodnik został poprawnie dodany.' }
        format.json { render :show, status: :created, location: @zawodnik }
      else
        format.html { render :new }
        format.json { render json: @zawodnik.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /zawodniks/1
  # PATCH/PUT /zawodniks/1.json
  def update
    respond_to do |format|
      if @zawodnik.update(zawodnik_params)
        format.html { redirect_to @zawodnik, notice: 'Dane zawodnika zostały zaktualizowane' }
        format.json { render :show, status: :ok, location: @zawodnik }
      else
        format.html { render :edit }
        format.json { render json: @zawodnik.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /zawodniks/1
  # DELETE /zawodniks/1.json
  def destroy
    @zawodnik.destroy
    respond_to do |format|
      format.html { redirect_to zawodniks_url, notice: 'Zawodnik został usunięty.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_zawodnik
      @zawodnik = Zawodnik.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def zawodnik_params
      params.require(:zawodnik).permit(:Nazwisko, :Imie, :PESEL, :Telefon, :Adres, :Status)
    end
end
